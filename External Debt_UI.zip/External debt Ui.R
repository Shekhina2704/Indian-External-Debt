library(shiny)
library(shinydashboard)
library(dplyr)
library(tseries)

#cols<-c("blue","red","purple","deepskyblue","orange","darkgreen","darkturquoise","gold","firebrick4","violetred")
ui<-dashboardPage(skin = "purple",
                  dashboardHeader(title="WINTERFELL STORES",titleWidth=1800),
                  dashboardSidebar(
                    sidebarMenu(
                      menuItem("Home", tabName = "home", icon = icon("home")),
                      menuItem("MULTILATERAL", tabName = "multilateral", icon=icon("bar-chart-o")),
                      menuItem("BILATERAL", tabName = "bilateral", icon=icon("bar-chart-o")),
                      menuItem("IMF", tabName = "imf", icon=icon("bar-chart-o")),
                      menuItem("TRADE CREDIT", tabName = "tradecredit", icon=icon("bar-chart-o")),
                      menuItem("COMMERCIAL BORROWING", tabName = "commercialborrowing", icon=icon("bar-chart-o")),
                      menuItem("NRI AND FC", tabName = "nriandfc", icon=icon("bar-chart-o")),
                      menuItem("RUPEE DEBT", tabName = "rupeedebt", icon=icon("bar-chart-o")),
                      menuItem("LONG TERM DEBT", tabName = "longtermdebt", icon=icon("bar-chart-o")),
                      menuItem("SHORT TERM DEBT", tabName = "shorttermdebt", icon=icon("bar-chart-o")),
                      menuItem("OTHERS", tabName = "others", icon=icon("bar-chart-o")),
                      menuItem("MOVING AVERAGE PLOTS", tabName = "mavg", icon=icon("bar-chart-o"))
                      
                      
                    )
                  ),
                  dashboardBody(
                    
                    tabItems(
                      tabItem(tabName = "home",
                              tags$img(
                                src = "https://lh3.googleusercontent.com/proxy/2M7gCLJCrM-O2xJbFaAoiuubJ_SDmePZFjnm7eHvBtEY0hRas9379pgLboWE_JCTxtwY1n4c-ezbjwV6nRKWtE1W3xXM2csjq_TXBvNuoqX_UHA4RdRchNFX-vKicXIhqAjMB0FuYQqq1RiuoQ",
                                height = "100%",
                                width="100%",
                                alt = "Oopsie")),
                      
                      tabItem(tabName="multilateral",
                              mainPanel(
                                tabsetPanel(type="tabs",
                                            tabPanel(id="tab1", title="GOVERNMENT BORROWING",
                                                     tags$img(src="total gb(mult).jpeg"),
                                                     tags$img(src="total cons gb(mult).jpeg"),
                                                     tags$img(src="ida cons gb(multi).jpeg"),
                                                     tags$img(src="others cons gb(mult).jpeg"),
                                                     tags$img(src="total nc gb (mult).jpeg"),
                                                     tags$img(src="ibrd nc gb(mult).jpeg"),
                                                     tags$img(src="others nc gb(mult).jpeg")),
                                            
                                            tabPanel(id="tab2",title="NON GOVERNMENT BORROWING",
                                                     tags$img(src="total ngb (mult).jpeg"),
                                                     tags$img(src="cons ngb(mult).jpeg"),
                                                     tags$img(src="total nc ngb.jpeg"),
                                                     tags$img(src="ps nc ngb(multi).jpeg"),
                                                     tags$img(src="ibrd nc ngb ps(mult).jpeg"),
                                                     tags$img(src="others nc ngb ps(mult).jpeg"),
                                                     tags$img(src="FI NC NGB(mult).jpeg"),
                                                     tags$img(src="IBRD nc ngb FI(mult).jpeg"),
                                                     tags$img(src="others NC ngb FI(mult).jpeg"),
                                                     tags$img(src="private sec NC NGB(mult).jpeg"),
                                                     tags$img(src="IBRD NC NGB PR.sec(mult).jpeg"),
                                                     tags$img(src="others NC NGB PR.sec(Multi).jpeg")),
                                                     
                                            
                                            tabPanel(id="tab3",title = "TOTAL MULTILATERAL",
                                                     tags$img(src="total multilateral.jpeg"))))),
                      
                      
                      tabItem(tabName="bilateral",
                              mainPanel(
                                tabsetPanel(type="tabs",
                                            tabPanel(id="tab1", title="GOVERNMENT BORROWING",
                                                     tags$img(src="total govt bor.jpeg"),
                                                     tags$img(src="concessional gb.jpeg"),
                                                     tags$img(src="non-concessional gb.jpeg")
                                                     
                                            ),
                                            tabPanel(id="tab2",title="NON GOVERNMENT BORROWING",
                                                     tags$img(src="total ngb.jpeg"),
                                                     tags$img(src="total concessional ngb.jpeg"),
                                                     tags$img(src="public sector concs ngb.jpeg"),
                                                     tags$img(src="financial institutions concs ngb.jpeg"),
                                                     tags$img(src="private sector conc ngb.jpeg"),
                                                     tags$img(src="total non-concessional ngb.jpeg"),
                                                     tags$img(src="public sector non-cons ngb.jpeg"),
                                                     tags$img(src="financial inst non cons ngb.jpeg"),
                                                     tags$img(src="private sector non cons ngb.jpeg")),
                                            
                                
                                              tabPanel(id="tab3",title = "TOTAL BILATERAL",
                                                     tags$img(src="total bilateral.jpeg"))))),
                      tabItem(tabName = "imf",
                              mainPanel(
                                tabsetPanel(type = "tabs",
                                            tabPanel(id="tab",title = "INTERNATIONAL MONETARY FUND",
                                                     tags$img(src="imf.jpeg"))))),
                      
                      tabItem(tabName = "tradecredit",
                              mainPanel(
                                tabsetPanel(type = "tabs",
                                            tabPanel(id="tab1",title = "TRADE CREDIT",
                                                     tags$img(src="total trade credit.jpeg"),
                                                     tags$img(src="buyers credit(tc).jpeg"),
                                                     tags$img(src="supp credit(tc).jpeg"),
                                                     tags$img(src="export credit component of bilat cred.jpeg"),
                                                     tags$img(src="export credit def.jpeg"))))),
                      
                      tabItem(tabName = "commercialborrowing",
                              mainPanel(
                                tabsetPanel(type = "tabs",
                                            tabPanel(id="tab1",title = "COMMERCIAL BORROWING",
                                                     tags$img(src="total cb.jpeg"),
                                                     tags$img(src="commer bank loans(cb).jpeg"),
                                                     tags$img(src="secr bor(cb).jpeg"),
                                                     tags$img(src="loans.jpeg"),
                                                     tags$img(src="self liq loans(cb).jpeg"))))),
                      
                      tabItem(tabName = "nriandfc",
                              mainPanel(
                                tabsetPanel(type = "tabs",
                                            tabPanel(id="tab1",title = "NRI AND FC.jpeg",
                                                     tags$img(src="nri and fc.jpeg"))))),
                      
                      tabItem(tabName = "rupeedebt",
                              mainPanel(
                                tabsetPanel(type = "tabs",
                                            tabPanel(id="tab",title = "RUPEE DEBT",
                                                     tags$img(src="total rd.jpeg"),
                                                     tags$img(src="def(rd).jpeg"),
                                                     tags$img(src="civ(rd).jpeg"))))),
                      
                      tabItem(tabName = "longtermdebt",
                              mainPanel(
                                tabsetPanel(type = "tabs",
                                            tabPanel(id="tab",title = "LONG TERM DEBT",
                                                     tags$img(src="total ltd.jpeg"))))),
                      
                      tabItem(tabName = "shorttermdebt",
                              mainPanel(
                                tabsetPanel(type = "tabs",
                                            tabPanel(id="tab1",title = "SHORT TERM DEBT",
                                                     tags$img(src="total std.jpeg"),
                                                     tags$img(src="nri dep(std).jpeg"),
                                                     tags$img(src="trade rel cred(std).jpeg"),
                                                     tags$img(src="6 to 1 yr(std).jpeg"),
                                                     tags$img(src="upto 6 moths(std).jpeg"),
                                                     tags$img(src="FII(std).jpeg"),
                                                     tags$img(src="treas inv bills.jpeg"),
                                                     tags$img(src="ext debt liab(std).jpeg"),
                                                     tags$img(src="ext debt cent bank(std).jpeg"),
                                                     tags$img(src="ext debt comer bank(std).jpeg"))))),
                      
                      tabItem(tabName = "others",
                              mainPanel(
                                tabsetPanel(type = "tabs",
                                            tabPanel(id="tab1",title = "OTHERS",
                                                     tags$img(src="gtd.jpeg"),
                                                     tags$img(src="conc debt td.jpeg"),
                                                     tags$img(src="std.jpeg"),
                                                     tags$img(src="debt stock.jpeg"),
                                                     tags$img(src="debt service ratio.jpeg"))))),
                      
                      tabItem(tabName = "mavg",
                              mainPanel(
                                tabsetPanel(type = "tabs",
                                            tabPanel(id="tab1",title = "TOTAL MULTILATERAL",
                                                     tags$img(src="total mult.png"),
                                                     tags$img(src="3 yr ma mult.png"),
                                                     tags$img(src="5 yr ma mult.png")),
                                
                                
                                            tabPanel(id="tab2",title = "TOTAL BILATERAL",
                                                     tags$img(src="bilateral.png"),
                                                     tags$img(src="3 yr ma bilat.png"),
                                                     tags$img(src="5 yr ma bilat.png")),
                               
                                            tabPanel(id="tab3",title = "IMF",
                                                     tags$img(src="imf.png"),
                                                     tags$img(src="3 yr ma imf.png"),
                                                     tags$img(src="5 yr ma imf.png")),
                                
                                            tabPanel(id="tab4",title = "TOTAL TRADE CREDIT",
                                                     tags$img(src="trade credit.png"),
                                                     tags$img(src="3 yr ma tc.png"),
                                                     tags$img(src="5 yr ma tc.png")),
                                
                                            tabPanel(id="tab5",title = "TOTAL COMMERCIAL BORROWING",
                                                     tags$img(src="cb.png"),
                                                     tags$img(src="3 yr ma cb.png"),
                                                     tags$img(src="5 yr ma cb.png")),
                                
                                            tabPanel(id="tab6",title = "NRI & FC DEPOSITS",
                                                     tags$img(src="nri.png"),
                                                     tags$img(src="3 yr ma nri.png"),
                                                     tags$img(src="5 yr ma nri.png")),
                               
                                            tabPanel(id="tab7",title = "TOTAL RUPEE DEBT",
                                                     tags$img(src="rd.png"),
                                                     tags$img(src="3 yr ma rd.png"),
                                                     tags$img(src="5 yr ma rd.png")),
                                
                                            tabPanel(id="tab8",title = "TOTAL LONG TERM DEBT",
                                                     tags$img(src="ltd.png"),
                                                     tags$img(src="3 yr ma ltd.png"),
                                                     tags$img(src="5 yr ma ltd.png")),
                               
                                            tabPanel(id="tab9",title = "TOTAL SHORT TERM DEBT",
                                                     tags$img(src="std.png"),
                                                     tags$img(src="3 yr ma std.png"),
                                                     tags$img(src="5 yr ma std.png")))))
                                
                              
                  )
                  )
)
server= function(input,output){

  output$Gokul <- renderImage({
    filename <- normalizePath(file.path(hemanth()))
    #(tags$img(src="20200418_100531.jpg",height=50,width=50))
    list(src=filename,
         height="300px",
         width="300px",
         alt="Oopsie")
  }, deleteFile = FALSE)
}
shinyApp(ui=ui,server = server)
